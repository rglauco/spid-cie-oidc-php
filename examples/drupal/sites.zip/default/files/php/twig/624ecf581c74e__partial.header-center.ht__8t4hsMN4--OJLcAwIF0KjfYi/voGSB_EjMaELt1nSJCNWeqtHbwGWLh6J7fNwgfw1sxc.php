<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @bootstrap_italia/layout/header/_partial.header-center.html.twig */
class __TwigTemplate_7bda3f650c5f61fd049fee7795e1cd8faf1948a4dd9d8b20b2a34a9769178c22 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 2
        $context["wrapper_classes"] = [0 => ((        // line 3
($context["header_center_light"] ?? null)) ? (" theme-light") : ("")), 1 => ((        // line 4
($context["header_center_small"] ?? null)) ? (" it-small-header") : (""))];
        // line 7
        echo "
<div class=\"it-header-center-wrapper";
        // line 8
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(($context["wrapper_classes"] ?? null), 8, $this->source)), "html", null, true);
        echo "\">
  <div class=\"";
        // line 9
        ((($context["header_container_type"] ?? null)) ? (print ($this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["header_container_type"] ?? null), "html", null, true))) : (print ("container")));
        echo "\">
    <div class=\"row\">
      <div class=\"col-12\">
        <div class=\"it-header-center-content-wrapper\">
          ";
        // line 13
        if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "brand", [], "any", false, false, true, 13)) {
            // line 14
            echo "            <div class=\"it-brand-wrapper\">
              ";
            // line 15
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "brand", [], "any", false, false, true, 15), 15, $this->source), "html", null, true);
            echo "
            </div>
          ";
        }
        // line 18
        echo "          ";
        $this->loadTemplate("@bootstrap_italia/layout/header/_partial.header-center-right-zone.html.twig", "@bootstrap_italia/layout/header/_partial.header-center.html.twig", 18)->display($context);
        // line 19
        echo "        </div>
      </div>
    </div>
  </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "@bootstrap_italia/layout/header/_partial.header-center.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  71 => 19,  68 => 18,  62 => 15,  59 => 14,  57 => 13,  50 => 9,  46 => 8,  43 => 7,  41 => 4,  40 => 3,  39 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("", "@bootstrap_italia/layout/header/_partial.header-center.html.twig", "/home/drupal/web/themes/contrib/bootstrap_italia/templates/layout/header/_partial.header-center.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 2, "if" => 13, "include" => 18);
        static $filters = array("escape" => 8, "join" => 8);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if', 'include'],
                ['escape', 'join'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
