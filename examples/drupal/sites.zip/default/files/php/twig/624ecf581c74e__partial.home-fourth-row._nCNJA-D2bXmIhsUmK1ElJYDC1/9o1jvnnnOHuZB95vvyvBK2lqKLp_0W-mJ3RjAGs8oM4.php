<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @bootstrap_italia/layout/front/_partial.home-fourth-row.html.twig */
class __TwigTemplate_94ce3ae7f5443aa48d666d8abcc341878040a7a8eace5fe3bcd1e0b5911630c1 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        $context["row_name"] = "home-fourth-row";
        // line 2
        echo "
";
        // line 3
        if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "home_fourth_row_full_width", [], "any", false, false, true, 3)) {
            // line 4
            echo "  <div class=\"";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["row_name"] ?? null), 4, $this->source), "html", null, true);
            echo "-full-width__wrapper\">
    ";
            // line 5
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "home_fourth_row_full_width", [], "any", false, false, true, 5), 5, $this->source), "html", null, true);
            echo "
  </div>
";
        }
        // line 8
        echo "
";
        // line 9
        if ((((twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "home_fourth_row_first", [], "any", false, false, true, 9) || twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "home_fourth_row_second", [], "any", false, false, true, 9)) || twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "home_fourth_row_third", [], "any", false, false, true, 9)) || twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "home_fourth_row_fourth", [], "any", false, false, true, 9))) {
            // line 10
            echo "  <div class=\"";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["row_name"] ?? null), 10, $this->source), "html", null, true);
            echo "__wrapper\">
    <div class=\"";
            // line 11
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["row_name"] ?? null), 11, $this->source), "html", null, true);
            echo " ";
            ((($context["home_content_container_type"] ?? null)) ? (print ($this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["home_content_container_type"] ?? null), "html", null, true))) : (print ("container")));
            echo "\">
      <div class=\"row\">

        ";
            // line 14
            if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "home_fourth_row_first", [], "any", false, false, true, 14)) {
                // line 15
                echo "          <div class=\"col ";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["row_name"] ?? null), 15, $this->source), "html", null, true);
                echo "__col ";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["row_name"] ?? null), 15, $this->source), "html", null, true);
                echo "__first\">
            ";
                // line 16
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "home_fourth_row_first", [], "any", false, false, true, 16), 16, $this->source), "html", null, true);
                echo "
          </div>
        ";
            }
            // line 19
            echo "
        ";
            // line 20
            if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "home_fourth_row_second", [], "any", false, false, true, 20)) {
                // line 21
                echo "          <div class=\"col ";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["row_name"] ?? null), 21, $this->source), "html", null, true);
                echo "__col ";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["row_name"] ?? null), 21, $this->source), "html", null, true);
                echo "__second\">
            ";
                // line 22
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "home_fourth_row_second", [], "any", false, false, true, 22), 22, $this->source), "html", null, true);
                echo "
          </div>
        ";
            }
            // line 25
            echo "
        ";
            // line 26
            if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "home_fourth_row_third", [], "any", false, false, true, 26)) {
                // line 27
                echo "          <div class=\"col ";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["row_name"] ?? null), 27, $this->source), "html", null, true);
                echo "__col ";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["row_name"] ?? null), 27, $this->source), "html", null, true);
                echo "__third\">
            ";
                // line 28
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "home_fourth_row_third", [], "any", false, false, true, 28), 28, $this->source), "html", null, true);
                echo "
          </div>
        ";
            }
            // line 31
            echo "
        ";
            // line 32
            if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "home_fourth_row_fourth", [], "any", false, false, true, 32)) {
                // line 33
                echo "          <div class=\"col ";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["row_name"] ?? null), 33, $this->source), "html", null, true);
                echo "__col ";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["row_name"] ?? null), 33, $this->source), "html", null, true);
                echo "__fourth\">
            ";
                // line 34
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "home_fourth_row_fourth", [], "any", false, false, true, 34), 34, $this->source), "html", null, true);
                echo "
          </div>
        ";
            }
            // line 37
            echo "
      </div>
    </div>
  </div>
";
        }
    }

    public function getTemplateName()
    {
        return "@bootstrap_italia/layout/front/_partial.home-fourth-row.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  144 => 37,  138 => 34,  131 => 33,  129 => 32,  126 => 31,  120 => 28,  113 => 27,  111 => 26,  108 => 25,  102 => 22,  95 => 21,  93 => 20,  90 => 19,  84 => 16,  77 => 15,  75 => 14,  67 => 11,  62 => 10,  60 => 9,  57 => 8,  51 => 5,  46 => 4,  44 => 3,  41 => 2,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "@bootstrap_italia/layout/front/_partial.home-fourth-row.html.twig", "/home/drupal/web/themes/contrib/bootstrap_italia/templates/layout/front/_partial.home-fourth-row.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 1, "if" => 3);
        static $filters = array("escape" => 4);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if'],
                ['escape'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
