<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* themes/contrib/bootstrap_italia/templates/layout/pages/page--front.html.twig */
class __TwigTemplate_c8ad3df7e0f19dd3e21666b92dbcb495f9e19918617fa41c481eb80af81e634f extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 36
        echo "<div id=\"page-front\">
  ";
        // line 37
        if (($context["back_to_top_enable"] ?? null)) {
            // line 38
            echo "    ";
            $this->loadTemplate("@bootstrap_italia_components/back_to_top/back_to_top.twig", "themes/contrib/bootstrap_italia/templates/layout/pages/page--front.html.twig", 38)->display(twig_array_merge($context, ["small" =>             // line 39
($context["back_to_top_small"] ?? null), "dark" =>             // line 40
($context["back_to_top_dark"] ?? null), "shadow" =>             // line 41
($context["back_to_top_shadow"] ?? null)]));
            // line 43
            echo "  ";
        }
        // line 44
        echo "  ";
        $this->loadTemplate("@bootstrap_italia/layout/header/_partial.header.html.twig", "themes/contrib/bootstrap_italia/templates/layout/pages/page--front.html.twig", 44)->display($context);
        // line 45
        echo "  ";
        $this->loadTemplate("@bootstrap_italia/layout/front/_partial.home-first-row.html.twig", "themes/contrib/bootstrap_italia/templates/layout/pages/page--front.html.twig", 45)->display($context);
        // line 46
        echo "  ";
        $this->loadTemplate("@bootstrap_italia/layout/front/_partial.home-second-row.html.twig", "themes/contrib/bootstrap_italia/templates/layout/pages/page--front.html.twig", 46)->display($context);
        // line 47
        echo "  ";
        $this->loadTemplate("@bootstrap_italia/layout/front/_partial.home-third-row.html.twig", "themes/contrib/bootstrap_italia/templates/layout/pages/page--front.html.twig", 47)->display($context);
        // line 48
        echo "  ";
        $this->loadTemplate("@bootstrap_italia/layout/front/_partial.home-fourth-row.html.twig", "themes/contrib/bootstrap_italia/templates/layout/pages/page--front.html.twig", 48)->display($context);
        // line 49
        echo "
  ";
        // line 55
        echo "
  ";
        // line 56
        $this->loadTemplate("@bootstrap_italia/layout/front/_partial.home-last-row.html.twig", "themes/contrib/bootstrap_italia/templates/layout/pages/page--front.html.twig", 56)->display($context);
        // line 57
        echo "  ";
        $this->loadTemplate("@bootstrap_italia/layout/footer/_partial.footer.html.twig", "themes/contrib/bootstrap_italia/templates/layout/pages/page--front.html.twig", 57)->display($context);
        // line 58
        echo "</div>
";
    }

    public function getTemplateName()
    {
        return "themes/contrib/bootstrap_italia/templates/layout/pages/page--front.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  79 => 58,  76 => 57,  74 => 56,  71 => 55,  68 => 49,  65 => 48,  62 => 47,  59 => 46,  56 => 45,  53 => 44,  50 => 43,  48 => 41,  47 => 40,  46 => 39,  44 => 38,  42 => 37,  39 => 36,);
    }

    public function getSourceContext()
    {
        return new Source("", "themes/contrib/bootstrap_italia/templates/layout/pages/page--front.html.twig", "/home/drupal/web/themes/contrib/bootstrap_italia/templates/layout/pages/page--front.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("if" => 37, "include" => 38);
        static $filters = array();
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['if', 'include'],
                [],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
