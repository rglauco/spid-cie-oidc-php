<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @bootstrap_italia_components/alert/alert.twig */
class __TwigTemplate_48a5e0b1a97b9eaa46f473b195c83f87deddffe59a79477f03deb77268f05662 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 15
        $context["dismissible"] = (($context["dismissible"]) ?? (true));
        // line 16
        $context["classes"] = twig_array_merge([0 => "alert", 1 => ((        // line 18
($context["type"] ?? null)) ? (("alert-" . $this->sandbox->ensureToStringAllowed(($context["type"] ?? null), 18, $this->source))) : ("")), 2 => ((        // line 19
($context["dismissible"] ?? null)) ? ("alert-dismissible fade show") : (""))], ((        // line 20
($context["utility_classes"] ?? null)) ? (($context["utility_classes"] ?? null)) : ([])));
        // line 21
        echo "
<div class=\"";
        // line 22
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(($context["classes"] ?? null), 22, $this->source), " "), "html", null, true);
        echo "\" role=\"alert\">
  ";
        // line 23
        if (($context["heading"] ?? null)) {
            // line 24
            echo "    <h4 class=\"alert-heading\">";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["heading"] ?? null), 24, $this->source), "html", null, true);
            echo "</h4>
  ";
        }
        // line 26
        echo "
  ";
        // line 27
        $this->displayBlock('content', $context, $blocks);
        // line 30
        echo "
  ";
        // line 31
        if (($context["dismissible"] ?? null)) {
            // line 32
            echo "    <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\">
      <span aria-hidden=\"true\">&times;</span>
    </button>
  ";
        }
        // line 36
        echo "</div>
";
    }

    // line 27
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 28
        echo "    ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["content"] ?? null), 28, $this->source), "html", null, true);
        echo "
  ";
    }

    public function getTemplateName()
    {
        return "@bootstrap_italia_components/alert/alert.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  87 => 28,  83 => 27,  78 => 36,  72 => 32,  70 => 31,  67 => 30,  65 => 27,  62 => 26,  56 => 24,  54 => 23,  50 => 22,  47 => 21,  45 => 20,  44 => 19,  43 => 18,  42 => 16,  40 => 15,);
    }

    public function getSourceContext()
    {
        return new Source("", "@bootstrap_italia_components/alert/alert.twig", "/home/drupal/web/themes/contrib/bootstrap_italia/src/components/alert/alert.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 15, "if" => 23, "block" => 27);
        static $filters = array("merge" => 20, "escape" => 22, "join" => 22);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if', 'block'],
                ['merge', 'escape', 'join'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
