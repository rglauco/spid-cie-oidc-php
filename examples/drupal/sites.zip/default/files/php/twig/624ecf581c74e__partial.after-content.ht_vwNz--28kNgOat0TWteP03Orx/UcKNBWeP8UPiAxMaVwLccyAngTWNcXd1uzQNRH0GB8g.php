<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @bootstrap_italia/layout/content/_partial.after-content.html.twig */
class __TwigTemplate_b303ce3e526e4dfe01872154130983ae2e4c70b7645c2d3be782a7f9031c4f85 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        $context["row_name"] = "after-content";
        // line 2
        echo "
";
        // line 3
        if ((((twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "after_content_first", [], "any", false, false, true, 3) || twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "after_content_second", [], "any", false, false, true, 3)) || twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "after_content_third", [], "any", false, false, true, 3)) || twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "after_content_fourth", [], "any", false, false, true, 3))) {
            // line 4
            echo "  <div class=\"";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["row_name"] ?? null), 4, $this->source), "html", null, true);
            echo "__wrapper\">
    <div class=\"";
            // line 5
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["row_name"] ?? null), 5, $this->source), "html", null, true);
            echo " ";
            ((($context["content_container_type"] ?? null)) ? (print ($this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["content_container_type"] ?? null), "html", null, true))) : (print ("container")));
            echo "\">
      <div class=\"row\">

        ";
            // line 8
            if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "after_content_first", [], "any", false, false, true, 8)) {
                // line 9
                echo "          <div class=\"col ";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["row_name"] ?? null), 9, $this->source), "html", null, true);
                echo "__col ";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["row_name"] ?? null), 9, $this->source), "html", null, true);
                echo "__first\">
            ";
                // line 10
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "after_content_first", [], "any", false, false, true, 10), 10, $this->source), "html", null, true);
                echo "
          </div>
        ";
            }
            // line 13
            echo "
        ";
            // line 14
            if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "after_content_second", [], "any", false, false, true, 14)) {
                // line 15
                echo "          <div class=\"col ";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["row_name"] ?? null), 15, $this->source), "html", null, true);
                echo "__col ";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["row_name"] ?? null), 15, $this->source), "html", null, true);
                echo "__second\">
            ";
                // line 16
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "after_content_second", [], "any", false, false, true, 16), 16, $this->source), "html", null, true);
                echo "
          </div>
        ";
            }
            // line 19
            echo "
        ";
            // line 20
            if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "after_content_third", [], "any", false, false, true, 20)) {
                // line 21
                echo "          <div class=\"col ";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["row_name"] ?? null), 21, $this->source), "html", null, true);
                echo "__col ";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["row_name"] ?? null), 21, $this->source), "html", null, true);
                echo "__third\">
            ";
                // line 22
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "after_content_third", [], "any", false, false, true, 22), 22, $this->source), "html", null, true);
                echo "
          </div>
        ";
            }
            // line 25
            echo "
        ";
            // line 26
            if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "after_content_fourth", [], "any", false, false, true, 26)) {
                // line 27
                echo "          <div class=\"col ";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["row_name"] ?? null), 27, $this->source), "html", null, true);
                echo "__col ";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["row_name"] ?? null), 27, $this->source), "html", null, true);
                echo "__fourth\">
            ";
                // line 28
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "after_content_fourth", [], "any", false, false, true, 28), 28, $this->source), "html", null, true);
                echo "
          </div>
        ";
            }
            // line 31
            echo "
      </div>
    </div>
  </div>
";
        }
        // line 36
        echo "
";
        // line 37
        if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "after_content_full_width", [], "any", false, false, true, 37)) {
            // line 38
            echo "  <div class=\"";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["row_name"] ?? null), 38, $this->source), "html", null, true);
            echo "-full-width__wrapper\">
    ";
            // line 39
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "after_content_full_width", [], "any", false, false, true, 39), 39, $this->source), "html", null, true);
            echo "
  </div>
";
        }
    }

    public function getTemplateName()
    {
        return "@bootstrap_italia/layout/content/_partial.after-content.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  145 => 39,  140 => 38,  138 => 37,  135 => 36,  128 => 31,  122 => 28,  115 => 27,  113 => 26,  110 => 25,  104 => 22,  97 => 21,  95 => 20,  92 => 19,  86 => 16,  79 => 15,  77 => 14,  74 => 13,  68 => 10,  61 => 9,  59 => 8,  51 => 5,  46 => 4,  44 => 3,  41 => 2,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "@bootstrap_italia/layout/content/_partial.after-content.html.twig", "/home/drupal/web/themes/contrib/bootstrap_italia/templates/layout/content/_partial.after-content.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 1, "if" => 3);
        static $filters = array("escape" => 4);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if'],
                ['escape'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
